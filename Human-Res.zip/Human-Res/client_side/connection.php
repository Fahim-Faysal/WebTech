<?php

$conn = mysqli_connect("localhost", "root", "", "company");
if(!$conn) { die(" Connection Error "); }

?>
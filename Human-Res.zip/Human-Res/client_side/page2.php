<?php

?>
<!DOCTYPE html>
<html>
    <p>No data in this page</p>
</html>